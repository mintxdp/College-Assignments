 class complex{
	int real,imag;
	public void setdata(int a,int b) {
		a=real;
		b=imag;
	}
	public void display() {
		System.out.println(real+" +"+" i"+(imag));
	}
	public void add(int x,int y,int x1,int y1 ) {
		real=x+y;
		imag=x1+y1;
	}
}
public class Q2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
